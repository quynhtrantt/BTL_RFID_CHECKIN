Dev/M4_MiddleWare/thirdparty/printf.o: \
 ../Dev/M4_MiddleWare/thirdparty/printf.c \
 ../Dev/M4_MiddleWare/thirdparty/printf.h
../Dev/M4_MiddleWare/thirdparty/printf.h:
