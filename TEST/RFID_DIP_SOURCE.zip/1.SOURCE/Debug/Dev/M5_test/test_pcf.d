Dev/M5_test/test_pcf.o: ../Dev/M5_test/test_pcf.c \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_system/app_system.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_rfid/driver_rfid.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_main.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_keypad/bsp_keypad.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_button/bsp_button.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_command/app_command.h
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_system/app_system.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_rfid/driver_rfid.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_main.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_keypad/bsp_keypad.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_button/bsp_button.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_command/app_command.h:
