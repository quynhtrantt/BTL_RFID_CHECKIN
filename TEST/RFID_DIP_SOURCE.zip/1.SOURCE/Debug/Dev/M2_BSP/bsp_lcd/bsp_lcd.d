Dev/M2_BSP/bsp_lcd/bsp_lcd.o: ../Dev/M2_BSP/bsp_lcd/bsp_lcd.c \
 ../Dev/M2_BSP/bsp_lcd/bsp_lcd.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_lcd/driver_lcd.h
../Dev/M2_BSP/bsp_lcd/bsp_lcd.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_lcd/driver_lcd.h:
