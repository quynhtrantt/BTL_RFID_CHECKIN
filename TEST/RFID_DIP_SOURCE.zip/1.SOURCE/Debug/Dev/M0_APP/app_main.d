Dev/M0_APP/app_main.o: ../Dev/M0_APP/app_main.c \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M4_MiddleWare/thirdparty/printf.h \
 ../Dev/M0_APP/app_main.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_system/app_system.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_rfid/driver_rfid.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_rfid/app_rfid.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_lcd/app_lcd.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_rfid/bsp_rfid.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_clock/app_clock.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_keypad/app_keypad.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_button/app_button.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal.h \
 ../Core/Inc/stm32f1xx_hal_conf.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_def.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f1xx.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f103xb.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Include/core_cm3.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Include/cmsis_version.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Include/cmsis_compiler.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Include/cmsis_gcc.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Device/ST/STM32F1xx/Include/system_stm32f1xx.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc_ex.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio_ex.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_exti.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma_ex.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_cortex.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash_ex.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_i2c.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_pwr.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_spi.h \
 C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_uart.h
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M4_MiddleWare/thirdparty/printf.h:
../Dev/M0_APP/app_main.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_system/app_system.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_rfid/driver_rfid.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_rfid/app_rfid.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_lcd/app_lcd.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_rfid/bsp_rfid.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_clock/app_clock.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_keypad/app_keypad.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_button/app_button.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal.h:
../Core/Inc/stm32f1xx_hal_conf.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_def.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f1xx.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Device/ST/STM32F1xx/Include/stm32f103xb.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Include/core_cm3.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Include/cmsis_version.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Include/cmsis_compiler.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Include/cmsis_gcc.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Device/ST/STM32F1xx/Include/system_stm32f1xx.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_rcc_ex.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_gpio_ex.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_exti.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_dma_ex.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_cortex.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_flash_ex.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_i2c.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_pwr.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_spi.h:
C:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/stm32f1xx_hal_uart.h:
