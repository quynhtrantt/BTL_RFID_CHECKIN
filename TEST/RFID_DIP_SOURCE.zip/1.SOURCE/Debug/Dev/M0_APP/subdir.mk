################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Dev/M0_APP/app_main.c 

OBJS += \
./Dev/M0_APP/app_main.o 

C_DEPS += \
./Dev/M0_APP/app_main.d 


# Each subdirectory must supply rules for building sources it contributes
Dev/M0_APP/%.o Dev/M0_APP/%.su Dev/M0_APP/%.cyclo: ../Dev/M0_APP/%.c Dev/M0_APP/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -IC:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -IC:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc -IC:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Device/ST/STM32F1xx/Include -IC:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Include -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_lcd" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_rfid" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_button" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_lcd" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_led" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_rfid" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_gpio" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_i2c" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_rfid" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_lcd" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_spi" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_keypad" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_keypad" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_clock" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_button" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_buzzer" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_uart" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_pcf8574" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M5_test" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_system" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_mcp" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_command" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_uart" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M4_MiddleWare" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M4_MiddleWare/thirdparty" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Dev-2f-M0_APP

clean-Dev-2f-M0_APP:
	-$(RM) ./Dev/M0_APP/app_main.cyclo ./Dev/M0_APP/app_main.d ./Dev/M0_APP/app_main.o ./Dev/M0_APP/app_main.su

.PHONY: clean-Dev-2f-M0_APP

