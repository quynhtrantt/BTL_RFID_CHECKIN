Dev/M0_APP/app_rfid/app_fakerfid.o: ../Dev/M0_APP/app_rfid/app_fakerfid.c \
 ../Dev/M0_APP/app_rfid/app_rfid.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_rfid/driver_rfid.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_system/app_system.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_rfid/bsp_rfid.h
../Dev/M0_APP/app_rfid/app_rfid.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_rfid/driver_rfid.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_system/app_system.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_rfid/bsp_rfid.h:
