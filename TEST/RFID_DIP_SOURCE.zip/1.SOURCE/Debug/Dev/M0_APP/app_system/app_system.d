Dev/M0_APP/app_system/app_system.o: ../Dev/M0_APP/app_system/app_system.c \
 ../Dev/M0_APP/app_system/app_system.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_rfid/driver_rfid.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_mcp/driver_mcp79410.h
../Dev/M0_APP/app_system/app_system.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_rfid/driver_rfid.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_mcp/driver_mcp79410.h:
