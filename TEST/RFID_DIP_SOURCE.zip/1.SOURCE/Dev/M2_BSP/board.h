#ifndef M2_BSP_BOARD_H_
#define M2_BSP_BOARD_H_

#include "stm32f1xx_hal.h"

extern SPI_HandleTypeDef hspi1;
extern UART_HandleTypeDef huart1;

#define I2C_PORT GPIOB
#define SCL_PIN GPIO_PIN_6
#define SDA_PIN GPIO_PIN_7

#define MCP_I2C_PORT GPIOB
#define MCP_SCL_PIN GPIO_PIN_10
#define MCP_SDA_PIN GPIO_PIN_11

#define BUTTON_1_PORT GPIOB
#define BUTTON_1_PIN GPIO_PIN_12

#define BUTTON_2_PORT GPIOB
#define BUTTON_2_PIN GPIO_PIN_9

#define BOARD_RED_LED_AVAILABLE 0
#if BOARD_RED_LED_AVAILABLE
#define LED_RED_PORT GPIOB
#define LED_RED_PIN GPIO_PIN_15
#endif
#define BOARD_GREEN_LED_AVAILABLE 0

#define KEYPAD_ROW_PORT GPIOA
#define KEYPAD_R0_PIN GPIO_PIN_0
#define KEYPAD_R1_PIN GPIO_PIN_1
#define KEYPAD_R2_PIN GPIO_PIN_2
#define KEYPAD_R3_PIN GPIO_PIN_3

#define KEYPAD_COL_PORT GPIOB
#define KEYPAD_C0_PIN GPIO_PIN_3
#define KEYPAD_C1_PIN GPIO_PIN_4
#define KEYPAD_C2_PIN GPIO_PIN_5

#define EEPROM_WP_PORT GPIOB
#define EEPROM_WP_PIN GPIO_PIN_5

#endif
