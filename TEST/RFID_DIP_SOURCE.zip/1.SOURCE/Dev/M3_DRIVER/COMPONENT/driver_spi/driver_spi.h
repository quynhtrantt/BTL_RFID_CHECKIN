#ifndef M3_DRIVER_COMPONENT_DRIVER_SPI_DRIVER_SPI_H_
#define M3_DRIVER_COMPONENT_DRIVER_SPI_DRIVER_SPI_H_

#include <stdint.h>
uint8_t Driver_SPI_TxRx(uint8_t data);

#endif
