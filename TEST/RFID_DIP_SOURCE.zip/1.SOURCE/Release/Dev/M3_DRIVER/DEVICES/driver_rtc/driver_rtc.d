Dev/M3_DRIVER/DEVICES/driver_rtc/driver_rtc.o: \
 ../Dev/M3_DRIVER/DEVICES/driver_rtc/driver_rtc.c \
 ../Dev/M3_DRIVER/DEVICES/driver_rtc/driver_rtc.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_i2c/driver_i2c.h
../Dev/M3_DRIVER/DEVICES/driver_rtc/driver_rtc.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_i2c/driver_i2c.h:
