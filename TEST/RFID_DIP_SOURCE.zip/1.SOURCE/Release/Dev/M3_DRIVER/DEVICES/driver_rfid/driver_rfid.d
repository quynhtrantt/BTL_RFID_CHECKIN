Dev/M3_DRIVER/DEVICES/driver_rfid/driver_rfid.o: \
 ../Dev/M3_DRIVER/DEVICES/driver_rfid/driver_rfid.c \
 ../Dev/M3_DRIVER/DEVICES/driver_rfid/driver_rfid.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_spi/driver_spi.h
../Dev/M3_DRIVER/DEVICES/driver_rfid/driver_rfid.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_spi/driver_spi.h:
