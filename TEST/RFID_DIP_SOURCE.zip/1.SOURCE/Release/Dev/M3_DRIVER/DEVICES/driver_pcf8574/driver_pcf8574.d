Dev/M3_DRIVER/DEVICES/driver_pcf8574/driver_pcf8574.o: \
 ../Dev/M3_DRIVER/DEVICES/driver_pcf8574/driver_pcf8574.c \
 ../Dev/M3_DRIVER/DEVICES/driver_pcf8574/driver_pcf8574.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_i2c/driver_i2c.h
../Dev/M3_DRIVER/DEVICES/driver_pcf8574/driver_pcf8574.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_i2c/driver_i2c.h:
