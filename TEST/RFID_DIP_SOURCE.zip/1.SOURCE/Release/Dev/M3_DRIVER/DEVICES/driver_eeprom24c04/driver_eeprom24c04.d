Dev/M3_DRIVER/DEVICES/driver_eeprom24c04/driver_eeprom24c04.o: \
 ../Dev/M3_DRIVER/DEVICES/driver_eeprom24c04/driver_eeprom24c04.c \
 ../Dev/M3_DRIVER/DEVICES/driver_eeprom24c04/driver_eeprom24c04.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_i2c/driver_i2c.h
../Dev/M3_DRIVER/DEVICES/driver_eeprom24c04/driver_eeprom24c04.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_i2c/driver_i2c.h:
