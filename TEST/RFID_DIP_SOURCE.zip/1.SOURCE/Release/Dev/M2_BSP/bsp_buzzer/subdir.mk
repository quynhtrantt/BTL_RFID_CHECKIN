################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Dev/M2_BSP/bsp_buzzer/bsp_buzzer.c 

OBJS += \
./Dev/M2_BSP/bsp_buzzer/bsp_buzzer.o 

C_DEPS += \
./Dev/M2_BSP/bsp_buzzer/bsp_buzzer.d 


# Each subdirectory must supply rules for building sources it contributes
Dev/M2_BSP/bsp_buzzer/%.o Dev/M2_BSP/bsp_buzzer/%.su Dev/M2_BSP/bsp_buzzer/%.cyclo: ../Dev/M2_BSP/bsp_buzzer/%.c Dev/M2_BSP/bsp_buzzer/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -IC:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -IC:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/STM32F1xx_HAL_Driver/Inc -IC:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Device/ST/STM32F1xx/Include -IC:/Users/Quynh/STM32Cube/Repository/STM32Cube_FW_F1_V1.8.7/Drivers/CMSIS/Include -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_lcd" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_rfid" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_button" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_lcd" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_led" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_rfid" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_gpio" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_i2c" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_rfid" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_lcd" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_spi" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_keypad" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_keypad" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_clock" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_eeprom24c04" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_eeprom24c04" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_rtc" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M0_APP/app_button" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_rtc" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M2_BSP/bsp_buzzer" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_uart" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/DEVICES/driver_pcf8574" -I"D:/file bai hoc/LAP TRINH HE THONG NHUNG/SOFTWARE/1.SOURCE/Dev/M5_test" -Os -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Dev-2f-M2_BSP-2f-bsp_buzzer

clean-Dev-2f-M2_BSP-2f-bsp_buzzer:
	-$(RM) ./Dev/M2_BSP/bsp_buzzer/bsp_buzzer.cyclo ./Dev/M2_BSP/bsp_buzzer/bsp_buzzer.d ./Dev/M2_BSP/bsp_buzzer/bsp_buzzer.o ./Dev/M2_BSP/bsp_buzzer/bsp_buzzer.su

.PHONY: clean-Dev-2f-M2_BSP-2f-bsp_buzzer

