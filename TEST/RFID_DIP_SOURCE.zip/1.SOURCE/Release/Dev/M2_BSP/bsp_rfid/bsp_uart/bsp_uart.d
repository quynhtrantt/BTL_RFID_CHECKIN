Dev/M2_BSP/bsp_rfid/bsp_uart/bsp_uart.o: \
 ../Dev/M2_BSP/bsp_rfid/bsp_uart/bsp_uart.c \
 ../Dev/M2_BSP/bsp_rfid/bsp_uart/bsp_uart.h \
 D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_uart/driver_uart.h
../Dev/M2_BSP/bsp_rfid/bsp_uart/bsp_uart.h:
D:/file\ bai\ hoc/LAP\ TRINH\ HE\ THONG\ NHUNG/SOFTWARE/1.SOURCE/Dev/M3_DRIVER/COMPONENT/driver_uart/driver_uart.h:
