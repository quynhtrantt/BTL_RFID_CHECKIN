################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

ELF_SRCS := 
OBJ_SRCS := 
S_SRCS := 
C_SRCS := 
S_UPPER_SRCS := 
O_SRCS := 
CYCLO_FILES := 
SIZE_OUTPUT := 
OBJDUMP_LIST := 
SU_FILES := 
EXECUTABLES := 
OBJS := 
MAP_FILES := 
S_DEPS := 
S_UPPER_DEPS := 
C_DEPS := 

# Every subdirectory with source files must be described here
SUBDIRS := \
Core/Src \
Core/Startup \
Dev/M0_APP/app_button \
Dev/M0_APP/app_clock \
Dev/M0_APP/app_keypad \
Dev/M0_APP/app_lcd \
Dev/M0_APP \
Dev/M0_APP/app_rfid \
Dev/M2_BSP/bsp_button \
Dev/M2_BSP/bsp_buzzer \
Dev/M2_BSP/bsp_keypad \
Dev/M2_BSP/bsp_lcd \
Dev/M2_BSP/bsp_led \
Dev/M2_BSP/bsp_rfid \
Dev/M2_BSP/bsp_rfid/bsp_uart \
Dev/M3_DRIVER/COMPONENT/driver_gpio \
Dev/M3_DRIVER/COMPONENT/driver_i2c \
Dev/M3_DRIVER/COMPONENT/driver_spi \
Dev/M3_DRIVER/COMPONENT/driver_uart \
Dev/M3_DRIVER/DEVICES/driver_eeprom24c04 \
Dev/M3_DRIVER/DEVICES/driver_lcd \
Dev/M3_DRIVER/DEVICES/driver_pcf8574 \
Dev/M3_DRIVER/DEVICES/driver_rfid \
Dev/M3_DRIVER/DEVICES/driver_rtc \
Dev/M5_test \
Drivers/STM32F1xx_HAL_Driver \

